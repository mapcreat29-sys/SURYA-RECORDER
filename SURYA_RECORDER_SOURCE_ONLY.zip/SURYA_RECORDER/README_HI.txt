SURYA RECORDER - Android starter project

जरूरी:
- Android Studio में यह पूरा folder खोलें.
- Gradle sync पूरा होने दें.
- फोन में Developer options > USB debugging चालू करके USB से जोड़ें.
- Android Studio में Run दबाएँ.
- पहली बार स्क्रीन रिकॉर्डिंग की अनुमति दें.

यह शुरुआती source-code प्रोजेक्ट है, तैयार/साइन किया हुआ APK नहीं.
इसमें 720p/1080p/2160p output size चुनने का prototype है; 4K असली 4K तभी होगा
जब फोन का display/capture pipeline और encoder उसे सपोर्ट करें. कुछ फोन पर 4K
चुनने पर recording शुरू नहीं हो सकती. 30 FPS रखा गया है ताकि शुरुआती build
ज्यादा स्थिर रहे.

ऑडियो: इस संस्करण में माइक्रोफोन ऑडियो है. Internal/game audio capture अभी
नहीं जोड़ा गया है. Android हर recording session के लिए screen-capture consent
मांगता है. ऐप की वीडियो फाइलें app-specific Movies/SURYA_RECORDER folder में
सेव होती हैं.

Production release से पहले:
- MediaProjection lifecycle/callback handling और Android 14+ behavior को और
  मजबूत करना.
- Encoder capabilities के आधार पर resolution/FPS dynamically जांचना.
- MediaStore में वीडियो सेव करना ताकि Gallery में आसानी से दिखे.
- 60 FPS और internal audio capture को अलग से implement/test करना.
