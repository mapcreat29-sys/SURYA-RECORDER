package com.suryarecorder

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val requestCapture = 1001
    private lateinit var quality: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(Color.rgb(15, 15, 20))
        }

        val title = TextView(this).apply {
            text = "SURYA RECORDER"
            textSize = 28f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 12)
        }
        val subtitle = TextView(this).apply {
            text = "Screen + Gaming Recorder"
            textSize = 15f
            setTextColor(Color.LTGRAY)
        }

        val label = TextView(this).apply {
            text = "Video resolution"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 28, 0, 8)
        }

        quality = Spinner(this)
        val options = listOf("1080p (Recommended)", "720p (Smoother)", "4K (only if supported)")
        quality.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)

        val start = Button(this).apply {
            text = "START RECORDING"
            setOnClickListener { requestScreenCapture() }
        }
        val stop = Button(this).apply {
            text = "STOP RECORDING"
            setOnClickListener {
                val i = Intent(this@MainActivity, RecordingService::class.java)
                i.action = RecordingService.ACTION_STOP
                startService(i)
            }
        }

        val note = TextView(this).apply {
            text = "Note: Android will show a screen-sharing permission prompt each time. 4K depends on your phone's display and video encoder. This starter version records microphone audio; internal game audio is not included yet."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 24, 0, 0)
        }

        listOf(title, subtitle, label, quality, start, stop, note).forEach {
            layout.addView(it)
        }
        setContentView(layout)
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Activity result callback kept simple for starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val choice = when (quality.selectedItemPosition) {
                1 -> "720"
                2 -> "2160"
                else -> "1080"
            }
            val serviceIntent = Intent(this, RecordingService::class.java).apply {
                action = RecordingService.ACTION_START
                putExtra(RecordingService.EXTRA_RESULT_CODE, resultCode)
                putExtra(RecordingService.EXTRA_DATA, data)
                putExtra(RecordingService.EXTRA_QUALITY, choice)
            }
            startForegroundService(serviceIntent)
            Toast.makeText(this, "Recording is starting…", Toast.LENGTH_SHORT).show()
        }
    }
}
