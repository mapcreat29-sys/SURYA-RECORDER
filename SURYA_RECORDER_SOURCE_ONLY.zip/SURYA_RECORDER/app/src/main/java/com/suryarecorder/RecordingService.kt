package com.suryarecorder

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import java.io.File

class RecordingService : Service() {
    companion object {
        const val ACTION_START = "com.suryarecorder.START"
        const val ACTION_STOP = "com.suryarecorder.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_QUALITY = "quality"
        private const val CHANNEL_ID = "surya_recording"
        private const val NOTIFICATION_ID = 41
    }

    private var recorder: MediaRecorder? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopRecording()
            ACTION_START -> {
                createNotificationChannel()
                startForeground(NOTIFICATION_ID, buildNotification())
                startRecording(intent)
            }
        }
        return START_NOT_STICKY
    }

    private fun startRecording(intent: Intent) {
        try {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val data = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(EXTRA_DATA)
            } ?: throw IllegalStateException("Screen capture permission data missing")

            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)

            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)

            val selected = intent.getStringExtra(EXTRA_QUALITY) ?: "1080"
            val targetLongSide = selected.toIntOrNull() ?: 1080
            val ratio = metrics.widthPixels.toFloat() / metrics.heightPixels.toFloat()
            val outWidth: Int
            val outHeight: Int
            if (metrics.widthPixels >= metrics.heightPixels) {
                outWidth = targetLongSide
                outHeight = (targetLongSide / ratio).toInt()
            } else {
                outHeight = targetLongSide
                outWidth = (targetLongSide * ratio).toInt()
            }
            // H.264 encoders generally require even dimensions.
            val width = outWidth / 2 * 2
            val height = outHeight / 2 * 2

            val folder = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "SURYA_RECORDER")
            if (!folder.exists()) folder.mkdirs()
            val output = File(folder, "SURYA_${System.currentTimeMillis()}.mp4")

            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder = r
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setVideoSize(width, height)
            r.setVideoFrameRate(30)
            r.setVideoEncodingBitRate(if (targetLongSide >= 2160) 20_000_000 else 8_000_000)
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(output.absolutePath)
            r.prepare()

            virtualDisplay = projection?.createVirtualDisplay(
                "SURYA_RECORDER_DISPLAY",
                width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, null
            )
            r.start()
            Toast.makeText(this, "Recording: ${output.name}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start: ${e.message}", Toast.LENGTH_LONG).show()
            stopRecording()
        }
    }

    private fun stopRecording() {
        try { recorder?.stop() } catch (_: Exception) { }
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) { }
        recorder = null
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "SURYA recording", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, RecordingService::class.java).apply { action = ACTION_STOP }
        val pending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("SURYA RECORDER")
            .setContentText("Screen recording is active")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .addAction(Notification.Action.Builder(null, "Stop", pending).build())
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        try { recorder?.release() } catch (_: Exception) { }
        try { virtualDisplay?.release() } catch (_: Exception) { }
        try { projection?.stop() } catch (_: Exception) { }
        super.onDestroy()
    }
}
